select * from rgw_eav_attribute where  attribute_code='created_at';
select * from eav_attribute where  attribute_code='created_at';

select * from rgw_eav_entity_attribute;
select * from eav_entity_attribute;

-- 1.1 ese attributes jin attr id or code ek jesa he
select * from rgw_eav_entity_attribute where attribute_id not in
(
    select m2.attribute_id from eav_entity_attribute m2 where  m2.attribute_id in  (
        select m1.attribute_id from eav_attribute m2 inner join rgw_eav_attribute m1 on m2.attribute_id=m1.attribute_id and m2.attribute_code=m1.attribute_code
    )
);

-- backup and insert
# create table temp_apr_7_eav_entity_attribute_act_bkp select * from eav_entity_attribute
 select * from temp_apr_7_eav_entity_attribute_act_bkp
-- insert : DONE ye kam 1.1 wali insert ki file save kr k usme table ka nam change kr k krlia

-- 1.2.1 ese attributes jin attr id or code ek jesa nain he + jo duplicate nahin hen
        create table shipping_attributes_mapping_data_insert_2
        select * from rgw_eav_entity_attribute mage1 where  mage1.attribute_id in  (
            -- isko sai krna he duplicates hata hen
            select m1.attribute_id from eav_attribute m2 inner join rgw_eav_attribute m1 on  m2.attribute_code=m1.attribute_code and m2.attribute_id!=m1.attribute_id
            where m1.attribute_code not in (
                select n.attribute_code from eav_attribute n group by n.attribute_code having count(n.attribute_code)>1
                )
        );
select entity_type_id, attribute_set_id, attribute_group_id, m1t2.m2_attribute_id as attribute_id, sort_order
from shipping_attributes_mapping_data_insert_2 m1t1
left join temp_apr_7_eav_attribute_mapping m1t2 on m1t1.attribute_id=m1t2.m1_attribute_id;

select * from temp_apr_7_eav_attribute_mapping;

-- INSERT IGNORE INTO eav_entity_attribute(entity_type_id, attribute_set_id, attribute_group_id, attribute_id, sort_order) VALUES (4, 22, 974, 2903, 1);



-- 1.2.2 ese attributes jin attr id or code ek jesa nain he + jo duplicate hen




SELECT ea.entity_attribute_id, ea.entity_type_id, ea.attribute_set_id, ea.attribute_group_id, ea.attribute_id, ea.sort_order,
       s.attribute_set_name,
       g.attribute_group_name,
       a.attribute_code,
       a.attribute_id,
       a.frontend_label,
       ea.sort_order
FROM eav_attribute_set s
LEFT JOIN eav_attribute_group g   ON s.attribute_set_id   = g.attribute_set_id
LEFT JOIN eav_entity_attribute ea ON g.attribute_group_id = ea.attribute_group_id
LEFT JOIN eav_attribute a         ON ea.attribute_id      = a.attribute_id
WHERE s.entity_type_id = 4
  and a.attribute_id =2898 -- ,2906)
-- and g.attribute_group_name='Shipping'
--  and s.attribute_set_name='Migration_sanctuary_lamps' -- in ('Migration_advent_wreaths__candles','shipperhq_shipping_group')
ORDER BY s.attribute_set_name,
         g.sort_order,
         ea.sort_order;

select * from eav_entity_varchar;
select * from catalog_product_entity_varchar where entity_id=191977;
select * from catalog_product_entity_decimal where entity_id=191977;
select * from catalog_product_entity_int where entity_id=191977;
select * from catalog_product_entity_datetime where entity_id=191977;
select * from catalog_product_entity_text where entity_id=191977;

select * from rgw_catalog_product_entity_varchar where entity_id=191977;
select * from rgw_catalog_product_entity_decimal where entity_id=191977;
select * from rgw_catalog_product_entity_int where entity_id=191977;


-- entity ID : 58921    ,sku : 176000-71
SELECT * FROM catalog_product_entity where entity_id=58921;
-- frontend_label: Shipping Fee : 1459 / 2898
select * from rgw_eav_attribute where attribute_id=1459;
select * from eav_attribute where frontend_label='Shipping Fee';
-- frontend_label: Handling Fee : 1461 / 2899
select * from rgw_eav_attribute where attribute_id=1461;
select * from eav_attribute where frontend_label='Handling Fee';

select * from rgw_catalog_product_entity_decimal where attribute_id=1459 and  entity_id=58921;
select * from rgw_catalog_product_entity_decimal where attribute_id=1461 and  entity_id=58921;

select * from rgw_catalog_product_entity_varchar where attribute_id=1459 and entity_id=58921;
select * from rgw_catalog_product_entity_int where attribute_id=1459 and  entity_id=58921;
-- migrate it
# select * from rgw_catalog_product_entity_datetime where attribute_id=1459 and  entity_id=58921;
# select * from rgw_catalog_product_entity_text where attribute_id=1459 and  entity_id=58921;

select * from catalog_product_entity_decimal where attribute_id=2898 and  entity_id=58921;
select * from catalog_product_entity_decimal where attribute_id=2899 and  entity_id=58921;

select * from catalog_product_entity_varchar where attribute_id=2898 and entity_id=58921;
select * from catalog_product_entity_int where attribute_id=2898 and  entity_id=58921;
select * from catalog_product_entity_datetime where attribute_id=2898 and  entity_id=58921;
select * from catalog_product_entity_text where attribute_id=2898 and  entity_id=58921;

-- migrating data for shpping fee and handling fee

select * from eav_attribute where attribute_code='shipperhq_handling_fee'   -- 2899
select * from rgw_eav_attribute where attribute_code='shipperhq_handling_fee'; -- 1461
select  2899 as attribute_id, store_id, entity_id, value from rgw_catalog_product_entity_decimal a where attribute_id=1461;

-- table : catalog_product_entity_decimal
select  2899 as attribute_id, store_id, entity_id, value from rgw_catalog_product_entity_decimal a where attribute_id=258;
select  2899 as attribute_id, store_id, entity_id, value from catalog_product_entity_decimal a where attribute_id=2899;

# insert into catalog_product_entity_decimal(attribute_id, store_id, entity_id, value)
# select  2899 as attribute_id, store_id, entity_id, value from rgw_catalog_product_entity_decimal a where attribute_id=1461;


-- verification query
    select  count(rcpei.entity_id) from catalog_product_entity_decimal rcpei where attribute_id=2906;
    select  count(rcpei.entity_id) from rgw_catalog_product_entity_decimal rcpei where attribute_id=258;
-- ---------------------------------

-- migrating data for shpping fee and handling fee

select * from eav_attribute where attribute_code='shipperhq_shipping_fee'   -- 2898
select * from rgw_eav_attribute where attribute_code='shipperhq_shipping_fee'; -- 1459
select  2898 as attribute_id, store_id, entity_id, value from rgw_catalog_product_entity_decimal a where attribute_id=1459;

-- table : catalog_product_entity_decimal
select  2898 as attribute_id, store_id, entity_id, value from rgw_catalog_product_entity_decimal a where attribute_id=258;
select  2898 as attribute_id, store_id, entity_id, value from catalog_product_entity_decimal a where attribute_id=2898;

# insert into catalog_product_entity_decimal(attribute_id, store_id, entity_id, value)
# select  2898 as attribute_id, store_id, entity_id, value from rgw_catalog_product_entity_decimal a where attribute_id=1459;


-- verification query
    select  count(rcpei.entity_id) from catalog_product_entity_decimal rcpei where attribute_id=2898;
    select  count(rcpei.entity_id) from rgw_catalog_product_entity_decimal rcpei where attribute_id=258;
-- ---------------------------------




-- mass verification
select
-- mapping table
select * from rgw_eav_entity_attribute where attribute_id=1459
select * from rgw_eav_entity_attribute where attribute_id=256

select * from eav_entity_attribute where attribute_id=2906
select * from eav_entity_attribute where attribute_id=2899

select * from rgw_eav_entity_attribute

select * from eav_attribute_group where attribute_group_name='Shipping'
select * from rgw_eav_attribute_group where attribute_group_name='Shipping'

select a.attribute_set_name,count(g.attribute_group_name) from eav_attribute_set a
inner join eav_attribute_group g on a.attribute_set_id=g.attribute_set_id
where attribute_group_name='Shipping'
group by a.attribute_set_name


-- from m1 with love
SELECT ea.entity_attribute_id, ea.entity_type_id, ea.attribute_set_id, ea.attribute_group_id, ea.attribute_id, ea.sort_order,
       s.attribute_set_name,
       g.attribute_group_name,
       a.attribute_code,
       a.attribute_id,
       a.frontend_label,
       ea.sort_order, rcped.value
FROM eav_attribute_set s
LEFT JOIN eav_attribute_group g   ON s.attribute_set_id   = g.attribute_set_id
LEFT JOIN eav_entity_attribute ea ON g.attribute_group_id = ea.attribute_group_id
LEFT JOIN eav_attribute a         ON ea.attribute_id      = a.attribute_id
left join catalog_product_entity_decimal rcped on ea.attribute_id=rcped.attribute_id
WHERE s.entity_type_id = 4
and a.attribute_id =2898 -- ,2906)
and g.attribute_group_name='Shipping'
-- and s.attribute_set_name='Migration_sanctuary_lamps' -- in ('Migration_advent_wreaths__candles','shipperhq_shipping_group')
and rcped.value=2703.0000
and rcped.entity_id=58921
ORDER BY s.attribute_set_name,
         g.sort_order,
         ea.sort_order;
